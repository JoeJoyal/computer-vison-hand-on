# object-detection-ASL > 2024-04-20 6:52pm
https://universe.roboflow.com/root-1nh6q/object-detection-asl

Provided by a Roboflow user
License: MIT

